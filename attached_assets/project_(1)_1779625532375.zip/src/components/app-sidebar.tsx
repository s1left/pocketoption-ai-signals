
"use client"

import * as React from "react"
import {
  LayoutDashboard,
  History,
  ShieldAlert,
  Settings,
  LogOut,
  Bot,
  Zap,
  BarChart3
} from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import Link from "next/link"
import { usePathname } from "next/navigation"

const items = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Signal History",
    url: "/history",
    icon: History,
  },
  {
    title: "AI Analysis",
    url: "/analysis",
    icon: BarChart3,
  },
  {
    title: "Admin Panel",
    url: "/admin",
    icon: ShieldAlert,
  },
]

export function AppSidebar() {
  const pathname = usePathname()

  return (
    <Sidebar variant="sidebar" collapsible="icon">
      <SidebarHeader className="p-4 flex items-center gap-3">
        <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
          <Zap className="h-5 w-5 text-white" />
        </div>
        <span className="font-headline font-bold text-sm tracking-tighter group-data-[collapsible=icon]:hidden">
          POCKET <span className="text-primary">AI</span> PRO
        </span>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu className="px-2">
          {items.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton 
                asChild 
                isActive={pathname === item.url}
                tooltip={item.title}
                className={pathname === item.url ? "text-primary" : "hover:text-primary"}
              >
                <Link href={item.url}>
                  <item.icon />
                  <span>{item.title}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton 
              className="hover:text-primary"
              onClick={() => {
                // Сбрасываем сессию, но не блокируем вход
                localStorage.removeItem("trader_id")
                window.location.reload()
              }}
            >
              <LogOut />
              <span>Reset Session</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
        <div className="mt-4 p-3 rounded-lg bg-muted/30 group-data-[collapsible=icon]:hidden border border-border">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[10px] font-medium uppercase tracking-widest text-muted-foreground">System Status</span>
          </div>
          <div className="text-[11px] text-foreground font-headline">AI ENGINE ONLINE</div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
