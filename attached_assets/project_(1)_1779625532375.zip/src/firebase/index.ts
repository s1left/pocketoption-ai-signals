
'use client';

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, collection, doc, onSnapshot, DocumentReference, Query, DocumentData, query, orderBy, limit } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { firebaseConfig } from './config';
import { useState, useEffect, useMemo } from 'react';

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export const useFirestore = () => db;
export const useAuth = () => auth;

export function useDoc(ref: DocumentReference | null) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!ref) {
      setLoading(false);
      return;
    }
    return onSnapshot(ref, (doc) => {
      setData(doc.exists() ? { id: doc.id, ...doc.data() } : null);
      setLoading(false);
    });
  }, [ref?.path]);

  return { data, loading };
}

export function useCollection(queryObj: Query | null) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!queryObj) {
      setLoading(false);
      return;
    }
    return onSnapshot(queryObj, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setData(items);
      setLoading(false);
    });
  }, [queryObj ? 'query-active' : 'query-null']);

  return { data, loading };
}
