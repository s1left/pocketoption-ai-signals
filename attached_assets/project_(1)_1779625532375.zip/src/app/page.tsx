
"use client"

import * as React from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { 
  Target,
  Menu,
  History as HistoryIcon,
  ShieldAlert,
  Coins,
  Globe,
  Pickaxe,
  Zap,
  Loader2,
  Trash2,
  Clock,
  Cpu
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { generateTradingSignal } from "@/ai/flows/generate-trading-signal"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useFirestore, useDoc, useCollection } from "@/firebase"
import { doc, collection, addDoc, query, orderBy, limit, deleteDoc, getDocs, writeBatch, updateDoc } from "firebase/firestore"
import { useToast } from "@/hooks/use-toast"

const ADMIN_ID = "8950661719";

const ASSETS = {
  "OTC": {
    icon: Zap,
    pairs: {
      "EUR/USD (OTC)": "FX:EURUSD",
      "GBP/USD (OTC)": "FX:GBPUSD",
      "AUD/USD (OTC)": "FX:AUDUSD",
      "USD/JPY (OTC)": "FX:USDJPY",
      "USD/CAD (OTC)": "FX:USDCAD",
      "NZD/USD (OTC)": "FX:NZDUSD",
      "EUR/GBP (OTC)": "FX:EURGBP",
      "GBP/JPY (OTC)": "FX:GBPJPY",
      "USD/CHF (OTC)": "FX:USDCHF",
      "EUR/JPY (OTC)": "FX:EURJPY",
      "AUD/CAD (OTC)": "FX:AUDCAD"
    }
  },
  "CURRENCIES": {
    icon: Globe,
    pairs: {
      "EUR/USD": "FX:EURUSD",
      "GBP/USD": "FX:GBPUSD",
      "USD/JPY": "FX:USDJPY",
      "AUD/USD": "FX:AUDUSD",
      "USD/CAD": "FX:USDCAD",
      "EUR/GBP": "FX:EURGBP",
      "EUR/JPY": "FX:EURJPY",
      "GBP/JPY": "FX:GBPJPY"
    }
  },
  "CRYPTO": {
    icon: Coins,
    pairs: {
      "BTC/USDT": "BINANCE:BTCUSDT",
      "ETH/USDT": "BINANCE:ETHUSDT",
      "SOL/USDT": "BINANCE:SOLUSDT"
    }
  },
  "COMMODITIES": {
    icon: Pickaxe,
    pairs: {
      "Gold": "OANDA:XAUUSD",
      "Silver": "OANDA:XAGUSD"
    }
  }
}

const ALL_SYMBOLS: Record<string, string> = Object.values(ASSETS).reduce((acc, cat) => ({ ...acc, ...cat.pairs }), {});

const EXPIRY_OPTIONS = [
  { label: "30S", value: "30s", seconds: 30 },
  { label: "1M", value: "1m", seconds: 60 },
  { label: "2M", value: "2m", seconds: 120 },
  { label: "5M", value: "5m", seconds: 300 }
] as const

declare global {
  interface Window {
    TradingView: any;
  }
}

function TradingViewChart({ symbol }: { symbol: string }) {
  const containerId = React.useMemo(() => `tv_chart_${symbol.replace(':', '_')}`, [symbol]);

  React.useEffect(() => {
    const scriptId = 'tradingview-widget-script';
    let script = document.getElementById(scriptId) as HTMLScriptElement;

    const initWidget = () => {
      if (typeof window.TradingView !== 'undefined' && document.getElementById(containerId)) {
        new window.TradingView.widget({
          "autosize": true,
          "symbol": symbol,
          "interval": "1",
          "timezone": "Etc/UTC",
          "theme": "dark",
          "style": "1", 
          "locale": "en",
          "toolbar_bg": "#f1f3f6",
          "enable_publishing": false,
          "hide_top_toolbar": true,
          "hide_legend": true,
          "save_image": false,
          "container_id": containerId,
          "backgroundColor": "rgba(0, 0, 0, 1)",
          "gridColor": "rgba(230, 0, 0, 0.05)",
          "allow_symbol_change": false,
          "hide_side_toolbar": true,
          "details": false,
          "hotlist": false,
          "calendar": false,
          "show_popup_button": false,
          "studies": ["RSI@tv-basicstudies"],
        });
      }
    };

    if (!script) {
      script = document.createElement("script");
      script.id = scriptId;
      script.src = "https://s3.tradingview.com/tv.js";
      script.async = true;
      script.onload = initWidget;
      document.head.appendChild(script);
    } else {
      initWidget();
    }

    return () => {
      const container = document.getElementById(containerId);
      if (container) container.innerHTML = '';
    };
  }, [symbol, containerId]);

  return (
    <div className="h-full w-full bg-black relative flex items-center justify-center">
      <div id={containerId} className="h-full w-full" />
      <div className="absolute inset-0 pointer-events-none border border-white/5 z-10" />
    </div>
  );
}

export default function Dashboard() {
  const router = useRouter()
  const db = useFirestore()
  const { toast } = useToast()
  const [traderId, setTraderId] = React.useState<string>(ADMIN_ID)
  
  React.useEffect(() => {
    const savedId = localStorage.getItem("trader_id")
    if (savedId) {
      setTraderId(savedId)
    } else {
      localStorage.setItem("trader_id", ADMIN_ID)
      setTraderId(ADMIN_ID)
    }
  }, [])

  const { data: userData } = useDoc(db && traderId ? doc(db, "users", traderId) : null)

  const historyQuery = React.useMemo(() => {
    if (!db || !traderId) return null;
    return query(collection(db, "users", traderId, "history"), orderBy("timestamp", "desc"), limit(15));
  }, [db, traderId]);

  const { data: historyData } = useCollection(historyQuery);

  const [selectedPair, setSelectedPair] = React.useState("EUR/USD (OTC)")
  const [selectedExpiry, setSelectedExpiry] = React.useState<"30s" | "1m" | "2m" | "5m">("1m")
  const [isAnalyzing, setIsAnalyzing] = React.useState(false)
  const [currentSignal, setCurrentSignal] = React.useState<any>(null)
  const [price, setPrice] = React.useState(1.08450)
  const [isSheetOpen, setIsSheetOpen] = React.useState(false)

  const isAdmin = traderId === ADMIN_ID

  React.useEffect(() => {
    const interval = setInterval(() => {
      setPrice(p => {
        const change = (Math.random() - 0.5) * 0.00018; 
        return parseFloat((p + change).toFixed(5));
      });
    }, 500)
    return () => clearInterval(interval)
  }, [])

  React.useEffect(() => {
    if (!db || !traderId || !historyData) return;

    const checkPendingSignals = async () => {
      const now = Date.now();
      const pendingSignals = historyData.filter(s => s.result === 'PENDING');

      for (const signal of pendingSignals) {
        const expirySeconds = EXPIRY_OPTIONS.find(o => o.value === signal.expiry)?.seconds || 60;
        const expiryTime = signal.timestamp + (expirySeconds * 1000);

        if (now >= expiryTime) {
          const finalPrice = price; 
          let finalResult = 'LOSS';
          
          if (signal.action === 'BUY' && finalPrice > signal.entryPrice) finalResult = 'WIN';
          if (signal.action === 'SELL' && finalPrice < signal.entryPrice) finalResult = 'WIN';

          const signalRef = doc(db, "users", traderId, "history", signal.id);
          updateDoc(signalRef, {
            result: finalResult,
            exitPrice: finalPrice,
            status: 'completed'
          });
          
          toast({ 
            title: `SIGNAL ${finalResult}`, 
            description: `${signal.pair} closed at ${finalPrice.toFixed(5)}`,
            variant: finalResult === 'WIN' ? 'default' : 'destructive'
          });
        }
      }
    };

    const interval = setInterval(checkPendingSignals, 1000);
    return () => clearInterval(interval);
  }, [db, traderId, historyData, price, toast]);

  const handleGenerateSignal = async () => {
    if (!db || !traderId) return;
    setIsAnalyzing(true)
    setCurrentSignal(null)

    try {
      const isOtc = selectedPair.includes('(OTC)');
      const result = await generateTradingSignal({
        currencyPair: selectedPair,
        requestedExpiry: selectedExpiry,
        currentPrice: price,
        isOtc: isOtc,
        indicators: { rsi: 30 + Math.random() * 40 }
      })

      if (result) {
        const entryPrice = price;
        setCurrentSignal({ ...result, entryPrice });
        const timestamp = Date.now();
        const historyRef = collection(db, "users", traderId, "history");
        
        addDoc(historyRef, {
          pair: selectedPair,
          action: result.action,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          expiry: selectedExpiry,
          entryPrice: entryPrice,
          result: 'PENDING',
          timestamp: timestamp,
          status: 'active'
        });
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handleClearHistory = async () => {
    if (!db || !traderId) return;
    try {
      const historyRef = collection(db, "users", traderId, "history");
      const snapshot = await getDocs(historyRef);
      const batch = writeBatch(db);
      snapshot.docs.forEach((doc) => {
        batch.delete(doc.ref);
      });
      await batch.commit();
      toast({ title: "HISTORY PURGED", description: "Your local signal records have been cleared." });
    } catch (err) {
      toast({ title: "ERROR", variant: "destructive", description: "Could not clear history." });
    }
  }

  return (
    <div className="flex flex-col h-[100dvh] w-full bg-black text-white overflow-hidden p-safe trading-grid">
      <header className="px-2 py-1 flex items-center justify-between z-50 bg-black/90 backdrop-blur-md border-b border-white/5 h-10">
        <div className="flex items-center gap-1.5">
          <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7 rounded-md bg-white/5 border border-white/10 active-scale">
                <Menu className="h-3 w-3 text-primary" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[75%] bg-black/95 backdrop-blur-3xl border-r border-white/5 text-white p-0">
               <ScrollArea className="h-full p-4">
                 <div className="space-y-4">
                   {Object.entries(ASSETS).map(([cat, data]) => (
                     <div key={cat} className="space-y-1">
                       <span className="text-[6px] font-headline text-white/30 uppercase tracking-widest flex items-center gap-1">
                         <data.icon className="h-2 w-2" />
                         {cat}
                       </span>
                       <div className="grid grid-cols-1 gap-1">
                         {Object.keys(data.pairs).map(pair => (
                           <Button 
                             key={pair} 
                             variant="outline" 
                             className={`h-8 text-[8px] font-headline justify-start border-white/5 active-scale ${selectedPair === pair ? 'bg-primary/20 border-primary' : ''}`}
                             onClick={() => { setSelectedPair(pair); setIsSheetOpen(false); }}
                           >
                             {pair}
                           </Button>
                         ))}
                       </div>
                     </div>
                   ))}
                 </div>
               </ScrollArea>
            </SheetContent>
          </Sheet>
          <div className="flex flex-col">
            <span className="text-[8px] font-headline font-black uppercase tracking-tighter text-white/90 leading-tight">{selectedPair}</span>
            <span className="text-[4px] font-headline text-green-500 font-bold uppercase tracking-widest opacity-80">@{userData?.username || traderId}</span>
          </div>
        </div>

        <nav className="flex items-center gap-2">
          <Link href="/history" className="flex items-center gap-1 px-1.5 py-0.5 rounded-md neon-border-blue bg-blue-500/5 active-scale">
            <HistoryIcon className="h-2 w-2 text-blue-500/60" />
            <span className="text-[6px] font-headline font-black text-blue-500/60 uppercase">History</span>
          </Link>
          
          {isAdmin && (
            <Link href="/admin" className="flex items-center gap-1 px-1.5 py-0.5 rounded-md neon-border-gold bg-yellow-500/5 active-scale">
              <ShieldAlert className="h-2 w-2 text-yellow-500/60" />
              <span className="text-[6px] font-headline font-black text-yellow-500/60 uppercase">Admin</span>
            </Link>
          )}
        </nav>

        <div className="bg-primary/5 border border-primary/20 rounded px-1.5 py-0.5">
          <span className="font-mono text-primary text-[10px] font-black tracking-tighter neon-text-red">
            {price.toFixed(5)}
          </span>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-1 space-y-1">
        <Card className="glass-morphism border-white/10 p-1 pt-0 space-y-1">
          <div className="flex items-center justify-between px-1 py-0.5">
             <div className="flex gap-1">
                {EXPIRY_OPTIONS.map(opt => (
                  <Button
                    key={opt.value}
                    variant={selectedExpiry === opt.value ? "default" : "outline"}
                    className={`h-5 px-2 text-[6px] font-headline font-black border-white/5 active-scale ${selectedExpiry === opt.value ? 'bg-primary' : 'bg-white/5'}`}
                    onClick={() => setSelectedExpiry(opt.value)}
                  >
                    {opt.label}
                  </Button>
                ))}
             </div>
             <Badge className="h-3 text-[4px] font-headline bg-white/5 border-white/10 flex items-center gap-1">
                <Cpu className="h-1.5 w-1.5" />
                NEURAL CORE v8.0
             </Badge>
          </div>

          <div className="min-h-[130px] flex flex-col items-center justify-center border border-white/5 rounded-xl bg-black/60 relative overflow-hidden neon-border-red">
            <div className="scanline" />
            {isAnalyzing ? (
              <div className="text-center space-y-2">
                <Loader2 className="h-4 w-4 text-primary animate-spin mx-auto" />
                <p className="font-headline text-[7px] text-primary animate-pulse font-black uppercase tracking-widest">
                  {selectedPair.includes('OTC') ? 'SCANNING OTC ALGORITHMS...' : 'ANALYZING EXCHANGE DATA...'}
                </p>
              </div>
            ) : currentSignal ? (
              <div className="w-full p-2 text-center space-y-1">
                <div className={`p-1 rounded-xl border ${currentSignal.action === 'BUY' ? 'border-green-500/40 bg-green-500/5' : 'border-primary/40 bg-primary/5'}`}>
                  <div className={`text-5xl font-headline font-black leading-none ${currentSignal.action === 'BUY' ? 'text-green-500 neon-text-green' : 'text-primary neon-text-red'}`}>
                    {currentSignal.action === 'BUY' ? 'CALL' : 'PUT'}
                  </div>
                  <div className="text-[5px] font-headline uppercase text-white/40 mt-1">{currentSignal.analysisExplanation}</div>
                </div>
                <div className="flex justify-center gap-4 pt-1">
                  <div className="text-center">
                    <span className="text-[4px] text-white/30 uppercase block">ENTRY</span>
                    <span className="text-[8px] font-headline font-black text-white">{currentSignal.entryPrice.toFixed(5)}</span>
                  </div>
                  <div className="text-center">
                    <span className="text-[4px] text-white/30 uppercase block">PROBABILITY</span>
                    <span className="text-[8px] font-headline font-black text-green-500">{currentSignal.confidence}%</span>
                  </div>
                  <div className="text-center">
                    <span className="text-[4px] text-white/30 uppercase block">EXPIRY</span>
                    <span className="text-[8px] font-headline font-black text-white">{selectedExpiry}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 opacity-20">
                <Target className="h-6 w-6 text-white" />
                <span className="text-[6px] font-headline font-black uppercase">Ready for Analysis</span>
              </div>
            )}
          </div>

          <Button 
            className="w-full h-8 font-headline text-[8px] font-bold uppercase bg-primary hover:bg-red-600 active-scale shadow-lg shadow-primary/20"
            onClick={handleGenerateSignal}
            disabled={isAnalyzing}
          >
            {isAnalyzing ? "SYNCHRONIZING..." : `ANALYZE ${selectedPair}`}
          </Button>
        </Card>

        <Card className="h-[340px] glass-morphism border-white/10 overflow-hidden bg-black relative">
          <TradingViewChart symbol={ALL_SYMBOLS[selectedPair]} />
        </Card>

        <Card className="glass-morphism border-white/10 overflow-hidden">
           <CardHeader className="p-1 border-b border-white/5 flex flex-row justify-between items-center h-7">
             <div className="flex items-center gap-2">
               <span className="text-[5px] font-headline font-black text-white/40 uppercase">LIVE TRANSACTION LOG</span>
               <div className="h-1 w-1 rounded-full bg-green-500 animate-pulse" />
             </div>
             <Button 
               variant="ghost" 
               size="icon" 
               className="h-4 w-4 text-white/20 hover:text-primary active-scale"
               onClick={handleClearHistory}
             >
               <Trash2 className="h-2 w-2" />
             </Button>
           </CardHeader>
           <CardContent className="p-0">
             <div className="max-h-[160px] overflow-y-auto">
               {historyData && historyData.length > 0 ? historyData.map(entry => (
                 <div key={entry.id} className="flex items-center justify-between px-2 py-1.5 border-b border-white/5 hover:bg-white/[0.02]">
                   <div className="flex flex-col">
                     <span className="text-[6px] font-black">{entry.pair}</span>
                     <span className="text-[4px] text-white/30">{entry.time} • @{entry.entryPrice?.toFixed(5)}</span>
                   </div>
                   <div className="flex items-center gap-2">
                     <span className={`text-[5px] font-black ${entry.action === 'BUY' ? 'text-green-500' : 'text-primary'}`}>
                        {entry.action === 'BUY' ? 'CALL' : 'PUT'}
                     </span>
                     {entry.result === 'PENDING' ? (
                       <Badge className="h-3 text-[4px] bg-white/5 text-white/40 border-white/10">
                         <Clock className="h-1.5 w-1.5 mr-0.5 animate-spin" />
                         PENDING
                       </Badge>
                     ) : (
                       <Badge className={`h-3 text-[4px] ${entry.result === 'WIN' ? 'bg-green-500/20 text-green-500 border-green-500/20' : 'bg-primary/20 text-primary border-primary/20'}`}>
                         {entry.result}
                       </Badge>
                     )}
                   </div>
                 </div>
               )) : (
                <div className="py-6 text-center">
                  <span className="text-[6px] font-headline text-white/10 uppercase tracking-widest">No signals recorded</span>
                </div>
               )}
             </div>
           </CardContent>
        </Card>
      </main>
    </div>
  )
}
