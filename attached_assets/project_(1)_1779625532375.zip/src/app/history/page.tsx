
"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { History, TrendingUp, TrendingDown, CheckCircle2, XCircle, ArrowLeft, Trash2, Clock } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useFirestore, useCollection } from "@/firebase"
import { collection, query, orderBy, getDocs, writeBatch } from "firebase/firestore"
import { useToast } from "@/hooks/use-toast"

const ADMIN_ID = "8950661719";

export default function HistoryPage() {
  const db = useFirestore()
  const { toast } = useToast()
  const [traderId, setTraderId] = React.useState<string>(ADMIN_ID)

  React.useEffect(() => {
    const id = localStorage.getItem("trader_id") || ADMIN_ID
    setTraderId(id)
  }, [])

  const historyQuery = React.useMemo(() => {
    if (!db || !traderId) return null;
    return query(collection(db, "users", traderId, "history"), orderBy("timestamp", "desc"));
  }, [db, traderId]);

  const { data: historyData, loading } = useCollection(historyQuery);

  const handleClearHistory = async () => {
    if (!db || !traderId) return;
    try {
      const historyRef = collection(db, "users", traderId, "history");
      const snapshot = await getDocs(historyRef);
      const batch = writeBatch(db);
      snapshot.docs.forEach((doc) => {
        batch.delete(doc.ref);
      });
      await batch.commit();
      toast({ title: "HISTORY PURGED", description: "Your trade logs have been permanently deleted." });
    } catch (err) {
      toast({ title: "ERROR", variant: "destructive", description: "Could not clear history." });
    }
  }

  const completedTrades = historyData?.filter(h => h.result !== "PENDING") || [];
  const winCount = completedTrades.filter(h => h.result === "WIN").length || 0;
  const totalCount = completedTrades.length || 0;
  const accuracy = totalCount > 0 ? ((winCount / totalCount) * 100).toFixed(1) : "0.0";

  return (
    <div className="flex flex-col h-[100dvh] w-full bg-black text-white overflow-hidden p-safe trading-grid">
      <header className="px-3 py-2 flex items-center justify-between border-b border-white/5 bg-black/90 backdrop-blur-md">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-7 w-7 rounded-md bg-white/5 active-scale">
            <ArrowLeft className="h-3 w-3 text-primary" />
          </Button>
        </Link>
        <h1 className="text-[10px] font-headline font-black uppercase tracking-widest">
          SIGNAL <span className="text-primary">HISTORY</span>
        </h1>
        <div className="w-7">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7 rounded-md text-white/20 hover:text-primary active-scale"
            onClick={handleClearHistory}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-2 space-y-2 pb-10">
        <div className="grid grid-cols-3 gap-1.5">
          <Card className="glass-morphism border-white/5 p-1.5 text-center">
            <span className="text-[5px] font-headline font-bold text-white/30 uppercase block mb-0.5">Accuracy</span>
            <div className="text-[10px] font-headline font-black text-green-500 neon-text-green">{accuracy}%</div>
          </Card>
          <Card className="glass-morphism border-white/5 p-1.5 text-center">
            <span className="text-[5px] font-headline font-bold text-white/30 uppercase block mb-0.5">Total Wins</span>
            <div className="text-[10px] font-headline font-black text-white">{winCount}</div>
          </Card>
          <Card className="glass-morphism border-white/5 p-1.5 text-center">
            <span className="text-[5px] font-headline font-bold text-white/30 uppercase block mb-0.5">Active</span>
            <div className="text-[10px] font-headline font-black text-primary neon-text-red">
              {historyData?.filter(h => h.result === "PENDING").length || 0}
            </div>
          </Card>
        </div>

        <Card className="glass-morphism border-white/5 overflow-hidden">
          <CardHeader className="p-2 border-b border-white/5">
            <CardTitle className="text-[7px] font-headline font-black uppercase tracking-widest flex items-center gap-1.5 text-white/60">
              <History className="h-2 w-2 text-primary" />
              Verified Performance Log
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-white/5">
              {loading ? (
                <div className="py-10 text-center"><span className="text-[8px] animate-pulse">SYNCHRONIZING...</span></div>
              ) : historyData && historyData.length > 0 ? historyData.map((row) => (
                <div key={row.id} className="flex items-center justify-between px-3 py-2 hover:bg-white/[0.02] transition-colors">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[8px] font-headline font-black text-white">{row.pair}</span>
                    <div className="flex items-center gap-1 text-[5px] font-mono text-white/30 uppercase">
                       <span>ENTRY: {row.entryPrice?.toFixed(5)}</span>
                       {row.exitPrice && <span>• EXIT: {row.exitPrice.toFixed(5)}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-0.5 px-1 rounded bg-white/5 border border-white/10">
                      {row.action === "BUY" ? (
                        <TrendingUp className="h-1.5 w-1.5 text-green-500" />
                      ) : (
                        <TrendingDown className="h-1.5 w-1.5 text-primary" />
                      )}
                      <span className={`text-[6px] font-headline font-black ${row.action === "BUY" ? "text-green-500" : "text-primary"}`}>
                        {row.action}
                      </span>
                    </div>

                    {row.result === 'PENDING' ? (
                       <div className="flex items-center gap-1 px-1.5 py-0.5 rounded border border-white/10 bg-white/5 text-white/40">
                         <Clock className="h-1.5 w-1.5 animate-spin" />
                         <span className="text-[6px] font-headline font-black uppercase">PROCESSING</span>
                       </div>
                    ) : (
                      <div className={`flex items-center gap-1 px-1.5 py-0.5 rounded border ${row.result === "WIN" ? "bg-green-500/10 border-green-500/20 text-green-500" : "bg-primary/10 border-primary/20 text-primary"}`}>
                        {row.result === "WIN" ? <CheckCircle2 className="h-1.5 w-1.5" /> : <XCircle className="h-1.5 w-1.5" />}
                        <span className="text-[6px] font-headline font-black uppercase">{row.result}</span>
                      </div>
                    )}
                  </div>
                </div>
              )) : (
                <div className="py-10 text-center text-white/10 uppercase font-headline text-[6px]">No market interactions found</div>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
