import { NextResponse } from 'next/server';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, setDoc, updateDoc } from 'firebase/firestore';
import { firebaseConfig } from '@/firebase/config';

// Глобальные настройки бота
const BOT_TOKEN = '8618852513:AAGPxAYEkCg6l1rVa1IaTOfG8UYyasyjo0A';
const ADMIN_ID = '8950661719';
const TELEGRAM_API = `https://api.telegram.org/bot${BOT_TOKEN}`;

// Инициализация Firebase (проверка на существующее приложение)
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const db = getFirestore(app);

async function sendTelegramMessage(chatId: string, text: string, replyMarkup?: any) {
  try {
    await fetch(`${TELEGRAM_API}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: 'HTML',
        reply_markup: replyMarkup,
      }),
    });
  } catch (e) {
    console.error('Bot: Error sending message:', e);
  }
}

async function editMessageText(chatId: string, messageId: number, text: string, replyMarkup?: any) {
  try {
    await fetch(`${TELEGRAM_API}/editMessageText`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId,
        text: text,
        parse_mode: 'HTML',
        reply_markup: replyMarkup,
      }),
    });
  } catch (e) {
    console.error('Bot: Error editing message:', e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const host = req.headers.get('host');
    const protocol = req.headers.get('x-forwarded-proto') || 'https';
    // На Netlify/Vercel baseUrl определится автоматически
    const baseUrl = `${protocol}://${host}`;

    // Обработка обычного сообщения (/start)
    if (body.message) {
      const { chat, text, from } = body.message;
      if (!from) return NextResponse.json({ ok: true });
      
      const userId = from.id.toString();
      const username = from.username || from.first_name || 'User';

      if (text === '/start') {
        const isDefaultAdmin = userId === ADMIN_ID;

        // Создаем или обновляем пользователя в базе
        await setDoc(doc(db, 'users', userId), {
          telegramId: userId,
          username: username,
          hasAccess: isDefaultAdmin,
          expiresAt: isDefaultAdmin ? -1 : 0,
          status: isDefaultAdmin ? 'active' : 'pending',
          createdAt: Date.now()
        }, { merge: true });

        if (isDefaultAdmin) {
          await sendTelegramMessage(userId, 
            `👑 <b>ДОБРО ПОЖАЛОВАТЬ, АДМИН!</b>\n\nСистема распознала вас автоматически. Доступ открыт навсегда.\n\n<a href="${baseUrl}/login?id=${userId}">📊 ВХОД В ТЕРМИНАЛ</a>`
          );
        } else {
          await sendTelegramMessage(userId, 
            `🚀 <b>POCKET AI PRO</b>\n\n👤 <b>${username}</b>, ваш запрос отправлен администратору.\n\n⏳ Ожидайте уведомления об активации доступа.`
          );

          // Уведомление админу
          const adminText = `🆕 <b>НОВЫЙ ЗАПРОС</b>\n\n👤: <b>${from.first_name}</b>\n🆔: <code>${userId}</code>\n🔗: @${from.username || '—'}\n\nВыберите срок доступа:`;
          
          const keyboard = {
            inline_keyboard: [
              [
                { text: '5ч', callback_data: `sel:${userId}:5h` },
                { text: '15ч', callback_data: `sel:${userId}:15h` },
                { text: '24ч', callback_data: `sel:${userId}:24h` }
              ],
              [
                { text: '15д', callback_data: `sel:${userId}:15d` },
                { text: '30д', callback_data: `sel:${userId}:30d` },
                { text: 'LIFE', callback_data: `sel:${userId}:life` }
              ],
              [{ text: '❌ ОТКЛОНИТЬ', callback_data: `decline:${userId}` }]
            ]
          };

          await sendTelegramMessage(ADMIN_ID, adminText, keyboard);
        }
      }
    }

    // Обработка нажатий на кнопки (callback queries)
    if (body.callback_query) {
      const { data, message } = body.callback_query;
      const [action, targetUserId, duration] = data.split(':');

      if (action === 'sel') {
        const keyboard = {
          inline_keyboard: [
            [
              { text: '✅ ПОДТВЕРДИТЬ', callback_data: `approve:${targetUserId}:${duration}` },
              { text: '↩️ НАЗАД', callback_data: `back:${targetUserId}` }
            ]
          ]
        };
        await editMessageText(ADMIN_ID, message.message_id, `🆔 ID: <code>${targetUserId}</code>\n📍 Срок: <b>${duration}</b>\n\nПодтверждаете выдачу?`, keyboard);
      }

      if (action === 'approve') {
        let expiry = 0;
        const now = Date.now();
        let label = "";

        if (duration === '5h') { expiry = now + 5 * 60 * 60 * 1000; label = "5 часов"; }
        else if (duration === '15h') { expiry = now + 15 * 60 * 60 * 1000; label = "15 часов"; }
        else if (duration === '24h') { expiry = now + 24 * 60 * 60 * 1000; label = "24 часа"; }
        else if (duration === '15d') { expiry = now + 15 * 24 * 60 * 60 * 1000; label = "15 дней"; }
        else if (duration === '30d') { expiry = now + 30 * 24 * 60 * 60 * 1000; label = "30 дней"; }
        else if (duration === 'life') { expiry = -1; label = "Бессрочно"; }

        await updateDoc(doc(db, 'users', targetUserId), {
          hasAccess: true,
          expiresAt: expiry,
          status: 'active'
        });

        const loginUrl = `${baseUrl}/login?id=${targetUserId}`;
        await editMessageText(ADMIN_ID, message.message_id, `✅ <b>ДОСТУП ВЫДАН!</b>\n\nID: <code>${targetUserId}</code>\nСрок: <b>${label}</b>`);
        
        await sendTelegramMessage(targetUserId, 
          `🎉 <b>ДОСТУП АКТИВИРОВАН!</b>\n\nСрок: <b>${label}</b>\n\nНажмите кнопку ниже для входа:`,
          { inline_keyboard: [[{ text: '📊 ТОРГОВЫЙ ТЕРМИНАЛ', url: loginUrl }]] }
        );
      }

      if (action === 'decline') {
        await updateDoc(doc(db, 'users', targetUserId), { status: 'blocked', hasAccess: false });
        await editMessageText(ADMIN_ID, message.message_id, `❌ Запрос <code>${targetUserId}</code> отклонен.`);
      }

      if (action === 'back') {
        const keyboard = {
          inline_keyboard: [
            [
              { text: '5ч', callback_data: `sel:${targetUserId}:5h` },
              { text: '15ч', callback_data: `sel:${targetUserId}:15h` },
              { text: '24ч', callback_data: `sel:${targetUserId}:24h` }
            ],
            [
              { text: '15д', callback_data: `sel:${targetUserId}:15d` },
              { text: '30д', callback_data: `sel:${targetUserId}:30d` },
              { text: 'LIFE', callback_data: `sel:${targetUserId}:life` }
            ],
            [{ text: '❌ ОТКЛОНИТЬ', callback_data: `decline:${targetUserId}` }]
          ]
        };
        await editMessageText(ADMIN_ID, message.message_id, `🔐 <b>ВЫБОР СРОКА</b>\n\nСрок для <code>${targetUserId}</code>:`, keyboard);
      }
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('Bot API Fatal Error:', error);
    return NextResponse.json({ ok: false }, { status: 500 });
  }
}
