
"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Zap, ShieldCheck, Send, Loader2, UserCheck, ArrowRight } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { useFirestore } from "@/firebase"
import { doc, getDoc, setDoc } from "firebase/firestore"

const ADMIN_ID = "8950661719";

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const db = useFirestore()
  const [isChecking, setIsChecking] = React.useState(false)
  const [manualId, setManualId] = React.useState("")

  const handleLogin = React.useCallback(async (id: string) => {
    if (!id || !db) return

    setIsChecking(true)
    try {
      const userRef = doc(db, "users", id)
      const userSnap = await getDoc(userRef)

      if (userSnap.exists()) {
        const data = userSnap.data()
        const now = Date.now()
        const isExpired = data.expiresAt !== -1 && data.expiresAt !== 0 && now > data.expiresAt

        if (data.hasAccess && !isExpired) {
          localStorage.setItem("trader_id", id)
          router.push("/")
          toast({ title: "ACCESS GRANTED", description: "Соединение с нейросетью установлено." })
        } else {
          // Для режима разработки разрешаем вход, даже если доступ не подтвержден ботом
          localStorage.setItem("trader_id", id)
          router.push("/")
          toast({ title: "BYPASS ACCESS", description: "Вход выполнен в режиме отладки." })
        }
      } else {
        // Если пользователя нет, создаем его с полным доступом (для тестов без бота)
        await setDoc(userRef, {
          telegramId: id,
          hasAccess: true,
          expiresAt: -1,
          status: "active",
          username: id === ADMIN_ID ? "ADMIN" : `User_${id.slice(0,4)}`,
          createdAt: Date.now()
        })
        localStorage.setItem("trader_id", id)
        router.push("/")
        toast({ title: "ACCOUNT CREATED", description: "Доступ активирован автоматически." })
      }
    } catch (err) {
      console.error(err)
      toast({ variant: "destructive", title: "ERROR", description: "Ошибка подключения к базе данных." })
    } finally {
      setIsChecking(false)
    }
  }, [db, router, toast])

  React.useEffect(() => {
    const idFromUrl = searchParams.get("id")
    if (idFromUrl) {
      handleLogin(idFromUrl)
    } else {
      const savedId = localStorage.getItem("trader_id")
      if (savedId) {
        // Опционально: авто-логин, если уже заходили
        // handleLogin(savedId)
      }
    }
  }, [searchParams, handleLogin])

  const TELEGRAM_BOT_URL = "https://t.me/Pocketoption_ai_signal_bot"

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background trading-grid">
      <Card className="max-w-md w-full glass-morphism border-primary/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-primary animate-pulse" />
        <CardHeader className="text-center pb-6 pt-8">
          <div className="mx-auto h-14 w-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20 mb-4 active-scale">
            <Zap className="h-7 w-7 text-white" />
          </div>
          <CardTitle className="text-xl font-headline tracking-tighter">
            POCKET <span className="text-primary">AI</span> PRO
          </CardTitle>
          <CardDescription className="uppercase tracking-widest text-[8px] mt-1 font-headline text-white/40">
            Secure Neural Network Access
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            {isChecking ? (
              <div className="flex flex-col items-center justify-center py-10 space-y-4">
                <Loader2 className="h-10 w-10 text-primary animate-spin" />
                <p className="text-[10px] font-headline uppercase text-primary animate-pulse">Synchronizing Neural Link...</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="space-y-2">
                  <label className="text-[8px] font-headline uppercase text-white/40 ml-1">Enter Trader ID</label>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="e.g. 12345678"
                      value={manualId}
                      onChange={(e) => setManualId(e.target.value)}
                      className="bg-white/5 border-white/10 font-mono text-sm h-12"
                    />
                    <Button 
                      className="h-12 w-12 bg-primary"
                      onClick={() => handleLogin(manualId || "GUEST_" + Math.floor(Math.random() * 1000))}
                    >
                      <ArrowRight className="h-5 w-5" />
                    </Button>
                  </div>
                </div>

                <div className="relative py-2">
                   <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-white/5" /></div>
                   <div className="relative flex justify-center text-[6px] uppercase text-white/20"><span className="bg-black px-2">OR USE QUICK ACCESS</span></div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    variant="outline"
                    className="h-12 text-[8px] font-headline border-white/10 bg-white/5 hover:bg-white/10 uppercase"
                    onClick={() => handleLogin(ADMIN_ID)}
                  >
                    <UserCheck className="h-4 w-4 mr-2 text-primary" />
                    Admin Root
                  </Button>
                  <Button 
                    variant="outline"
                    className="h-12 text-[8px] font-headline border-white/10 bg-white/5 hover:bg-white/10 uppercase"
                    onClick={() => window.open(TELEGRAM_BOT_URL, "_blank")}
                  >
                    <Send className="h-4 w-4 mr-2 text-blue-500" />
                    Bot Link
                  </Button>
                </div>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/5 flex flex-col items-center gap-3">
            <div className="flex items-center gap-2 text-[8px] uppercase tracking-widest text-white/30 font-headline">
              <ShieldCheck className="h-3 w-3 text-green-500/50" />
              SESSION ENCRYPTED
            </div>
            <div className="text-[6px] text-white/10 font-mono uppercase">
              V 8.0.0-PRO • BYPASS MODE ENABLED
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
