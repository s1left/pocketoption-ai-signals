"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart3, TrendingUp, Activity, Crosshair } from "lucide-react"
import { 
  ChartContainer, 
  ChartTooltip, 
  ChartTooltipContent,
  type ChartConfig
} from "@/components/ui/chart"
import { Line, LineChart, XAxis, YAxis, ResponsiveContainer, Area, AreaChart } from "recharts"

const chartData = [
  { time: "10:00", value: 1.0845, trend: 1.0850 },
  { time: "10:05", value: 1.0848, trend: 1.0849 },
  { time: "10:10", value: 1.0852, trend: 1.0851 },
  { time: "10:15", value: 1.0842, trend: 1.0848 },
  { time: "10:20", value: 1.0838, trend: 1.0842 },
  { time: "10:25", value: 1.0841, trend: 1.0840 },
  { time: "10:30", value: 1.0849, trend: 1.0845 },
]

const chartConfig: ChartConfig = {
  value: {
    label: "Price",
    color: "#E60000",
  },
  trend: {
    label: "AI Trendline",
    color: "#444444",
  },
}

export default function AnalysisPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <header className="border-b border-border pb-6">
        <h1 className="text-3xl font-headline font-extrabold tracking-tighter uppercase">
          Technical <span className="text-primary">Core</span>
        </h1>
        <p className="text-muted-foreground text-sm flex items-center gap-2">
          Real-time market scanning and trend identification
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-card border-border">
          <CardHeader>
            <CardTitle className="font-headline text-sm uppercase flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              PRICE VOLATILITY SCAN
            </CardTitle>
          </CardHeader>
          <CardContent className="h-[350px]">
            <ChartContainer config={chartConfig} className="h-full w-full">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#E60000" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#E60000" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#444" fontSize={10} />
                <YAxis hide />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Area type="monotone" dataKey="value" stroke="#E60000" fillOpacity={1} fill="url(#colorValue)" />
                <Line type="monotone" dataKey="trend" stroke="#444" strokeDasharray="5 5" dot={false} />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="font-headline text-sm uppercase flex items-center gap-2">
                <Activity className="h-4 w-4 text-primary" />
                RSI SCANNER
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="h-2 w-full bg-muted/20 rounded-full relative">
                  <div className="absolute top-0 left-[30%] right-[30%] h-full bg-primary/10 border-x border-primary/20" />
                  <div className="absolute top-[-4px] left-[55%] h-4 w-1 bg-primary shadow-lg shadow-primary/50" />
                </div>
                <div className="flex justify-between text-[10px] font-headline uppercase text-muted-foreground">
                  <span>Oversold</span>
                  <span>Neutral (55.4)</span>
                  <span>Overbought</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="font-headline text-sm uppercase flex items-center gap-2">
                <Crosshair className="h-4 w-4 text-primary" />
                PATTERN RECOGNITION
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                 {[
                   { name: "Double Bottom", prob: "84%", type: "Bullish" },
                   { name: "Head & Shoulders", prob: "62%", type: "Bearish" },
                   { name: "Rising Wedge", prob: "45%", type: "Bearish" }
                 ].map(pattern => (
                   <div key={pattern.name} className="flex items-center justify-between p-2 rounded bg-muted/10 border border-border">
                      <span className="text-xs font-headline">{pattern.name}</span>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] uppercase font-bold ${pattern.type === 'Bullish' ? 'text-green-500' : 'text-primary'}`}>{pattern.type}</span>
                        <Badge variant="outline" className="text-[10px] font-mono">{pattern.prob}</Badge>
                      </div>
                   </div>
                 ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
