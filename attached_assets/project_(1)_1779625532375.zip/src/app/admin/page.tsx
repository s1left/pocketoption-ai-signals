
"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  ShieldCheck, 
  Trash2, 
  Search, 
  ArrowLeft,
  Users,
  AlertTriangle,
  Clock,
  UserPlus
} from "lucide-react"
import Link from "next/link"
import { useFirestore, useCollection } from "@/firebase"
import { doc, updateDoc, deleteDoc, collection } from "firebase/firestore"
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

const ADMIN_ID = "8950661719"

const TIME_OPTIONS = [
  { label: "5 HOURS", value: 5 * 60 * 60 * 1000 },
  { label: "15 HOURS", value: 15 * 60 * 60 * 1000 },
  { label: "24 HOURS", value: 24 * 60 * 60 * 1000 },
  { label: "15 DAYS", value: 15 * 24 * 60 * 60 * 1000 },
  { label: "30 DAYS", value: 30 * 24 * 60 * 60 * 1000 },
  { label: "LIFETIME", value: -1 },
]

export default function AdminPage() {
  const db = useFirestore()
  const { data: usersData, loading } = useCollection(db ? collection(db, "users") : null)
  const [search, setSearch] = React.useState("")
  const { toast } = useToast()

  const handleGrantAccess = async (userId: string, duration: number) => {
    if (!db) return
    const expiry = duration === -1 ? -1 : Date.now() + duration
    
    try {
      await updateDoc(doc(db, "users", userId), {
        hasAccess: true,
        expiresAt: expiry,
        status: "active"
      })
      toast({ title: "ACCESS UPDATED", description: `License synchronized for ${userId}` })
    } catch (err) {
      toast({ title: "ERROR", variant: "destructive" })
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (!db) return
    try {
      await deleteDoc(doc(db, "users", userId))
      toast({ title: "SYSTEM TERMINATED", variant: "destructive" })
    } catch (err) {
      toast({ title: "ERROR" })
    }
  }

  const filteredUsers = usersData?.filter(u => 
    u.telegramId?.toLowerCase().includes(search.toLowerCase()) || 
    u.username?.toLowerCase().includes(search.toLowerCase())
  ) || []

  const formatExpiry = (expiresAt: number) => {
    if (expiresAt === -1) return "LIFETIME"
    if (expiresAt === 0 || !expiresAt) return "NO ACCESS"
    const diff = expiresAt - Date.now()
    if (diff < 0) return "EXPIRED"
    const hours = Math.floor(diff / (1000 * 60 * 60))
    if (hours < 24) return `${hours}H LEFT`
    return `${Math.floor(hours / 24)}D LEFT`
  }

  return (
    <div className="flex flex-col h-[100dvh] w-full bg-black text-white overflow-hidden p-safe trading-grid">
      <header className="px-3 py-2 flex items-center justify-between border-b border-white/5 bg-black/90 backdrop-blur-md">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-7 w-7 rounded-md bg-white/5 active-scale">
            <ArrowLeft className="h-3 w-3 text-primary" />
          </Button>
        </Link>
        <h1 className="text-[10px] font-headline font-black uppercase tracking-widest">
          ADMIN <span className="text-primary">CONTROL</span>
        </h1>
        <div className="w-7" />
      </header>

      <main className="flex-1 overflow-y-auto p-2 space-y-2 pb-10">
        <div className="grid grid-cols-2 gap-1.5">
          <Card className="glass-morphism border-white/5 p-2 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[5px] font-headline font-bold text-white/30 uppercase">Total Users</span>
              <div className="text-[12px] font-headline font-black">{usersData?.length || 0}</div>
            </div>
            <Users className="h-3 w-3 text-white/10" />
          </Card>
          <Card className="glass-morphism border-white/5 p-2 flex items-center justify-between border-green-500/20">
            <div className="flex flex-col">
              <span className="text-[5px] font-headline font-bold text-white/30 uppercase">Active Nodes</span>
              <div className="text-[12px] font-headline font-black text-green-500">
                {usersData?.filter(u => u.hasAccess && (u.expiresAt === -1 || u.expiresAt > Date.now())).length || 0}
              </div>
            </div>
            <ShieldCheck className="h-3 w-3 text-green-500/20" />
          </Card>
        </div>

        <Card className="glass-morphism border-white/5 overflow-hidden">
          <CardHeader className="p-2 border-b border-white/5 flex flex-row items-center justify-between bg-white/[0.02]">
            <CardTitle className="text-[7px] font-headline font-black uppercase tracking-widest text-white/60 flex items-center gap-1.5">
              <UserPlus className="h-2 w-2 text-primary" />
              Manage Licenses
            </CardTitle>
            <div className="relative">
              <Search className="absolute left-1.5 top-1/2 -translate-y-1/2 h-2 w-2 text-white/30" />
              <Input 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search..." 
                className="h-5 pl-4 pr-1 text-[6px] bg-white/5 border-white/10 w-24 focus:w-32 transition-all" 
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-white/5">
              {filteredUsers.length > 0 ? filteredUsers.map((user) => (
                <div key={user.id} className="flex items-center justify-between px-3 py-2 hover:bg-white/[0.02] transition-colors">
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1">
                      <div className={`h-1 w-1 rounded-full ${user.hasAccess ? 'bg-green-500' : 'bg-primary'}`} />
                      <span className="text-[8px] font-headline font-black text-white">@{user.username || user.telegramId}</span>
                    </div>
                    <span className="text-[5px] font-headline text-white/30 uppercase pl-2">
                      {formatExpiry(user.expiresAt)} • ID: {user.telegramId}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-white/20 hover:text-green-500 active-scale">
                          <Clock className="h-2.5 w-2.5" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-black/95 border-white/10 text-white w-[90%] max-w-[300px] rounded-xl backdrop-blur-xl p-4">
                        <DialogHeader>
                          <DialogTitle className="font-headline text-[10px] uppercase text-primary text-center">Set License Duration</DialogTitle>
                        </DialogHeader>
                        <div className="grid grid-cols-2 gap-2 mt-4">
                          {TIME_OPTIONS.map((opt) => (
                            <Button 
                              key={opt.label}
                              variant="outline"
                              className="text-[8px] font-headline h-8 bg-white/5 border-white/10 hover:border-primary active-scale"
                              onClick={() => handleGrantAccess(user.id, opt.value)}
                            >
                              {opt.label}
                            </Button>
                          ))}
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleDeleteUser(user.id)}
                      className="h-6 w-6 text-white/20 hover:text-primary active-scale"
                    >
                      <Trash2 className="h-2.5 w-2.5" />
                    </Button>
                  </div>
                </div>
              )) : (
                <div className="py-10 text-center space-y-2">
                  <AlertTriangle className="h-4 w-4 text-white/10 mx-auto" />
                  <p className="text-[6px] font-headline text-white/20 uppercase">No records found</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
